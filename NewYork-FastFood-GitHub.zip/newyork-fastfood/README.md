# New York Fast Food — Urganch

GitHub Pages ready website for **New York Fast Food** (Urganch, Xorazm).

## Contents

- `index.html` — main page (Uzbek)
- `images/` — all product photos + full menu poster

## How to upload to GitHub

1. Create a new repository (e.g. `newyork-fastfood`).
2. Upload **all** files and the `images` folder.
3. Enable **GitHub Pages** (Settings → Pages → Deploy from branch `main` / root).
4. Your site will be live at:  
   `https://YOUR-USERNAME.github.io/newyork-fastfood/`

## Contact

- Phone: +998 95 540 60 60
- Instagram: [@new_york_foood](https://instagram.com/new_york_foood)
